# import necessary libraries
from flask import Flask, render_template
import pandas as pd

# create instance of Flask app
app = Flask(__name__)


# create route that renders index.html template
@app.route("/")
def index():
    df = pd.read_csv("movies.csv")
    df = df.to_dict()
    print(df["movies"][0])
    # player_dictionary = {"player_1": "Jessica",
    #                      "player_2": "Mark"}
    return render_template("index.html", movies=df)


if __name__ == "__main__":
    app.run(debug=True)
