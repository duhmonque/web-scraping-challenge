# import necessary libraries
from flask import Flask, render_template

# create instance of Flask app
app = Flask(__name__)


# create route that renders index.html template
@app.route("/")
def echo():
    return render_template("index.html", title="Home", name="Drew")

@app.route("/about")
def about():
    return render_template("about.html", title="About Page")


if __name__ == "__main__":
    app.run(debug=True)
