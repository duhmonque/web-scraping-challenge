# import necessary libraries
from flask import Flask, render_template
import pandas as pd

# create instance of Flask app
app = Flask(__name__)


# create route that renders index.html template
@app.route("/")
def index():
    df = pd.read_csv("movies.csv")
    movie_list = df["movies"].to_list()
    rating_list = df["ratings"].to_list()
    print(movie_list)
  
    return render_template("index.html", list=movie_list, ratings=rating_list)


if __name__ == "__main__":
    app.run(debug=True)
