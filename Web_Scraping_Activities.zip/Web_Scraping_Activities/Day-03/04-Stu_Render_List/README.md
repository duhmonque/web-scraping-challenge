# Movie list

## Instructions

* Create a web page that will display a list of your top five favorite movies.

* Add style to your webpage by using [Bootstrap cards](https://getbootstrap.com/docs/4.0/components/card/) and additional movie information, such as a link to IMDB.
